import Phaser from 'phaser';
import backgroundUrl from '../../assets/images/Room3/room3-background.png.png';
import Doorway from '../game/Doorway';
import CrystalHolder from '../game/CrystalHolder';

const BACKGROUND_KEY = 'room3-background';
const OVERLAY_DEPTH = 90;

// The staircase opening painted into the lower-right corner of the
// 1536x1024 attic background. It is the return path to the Central Hall.
const EXIT_CENTER_X = 1402;
const EXIT_CENTER_Y = 875;
const EXIT_SIZE = { widthBg: 210, heightBg: 250 };

const ENTRY_START_ZOOM = 1.35;
const ENTRY_START_OVERLAY_ALPHA = 0.72;
const ENTRY_SETTLE_DURATION_MS = 650;
const EXIT_FADE_MS = 400;

/**
 * Room 3 environment shell.
 *
 * This sprint intentionally adds only the attic background, entry settle,
 * persistent crystal holder, and a working return exit. Puzzle logic and
 * green-crystal collection are not implemented yet.
 */
export default class Room3Scene extends Phaser.Scene {
  private background?: Phaser.GameObjects.Image;
  private exit?: Doorway;
  private crystalHolder?: CrystalHolder;
  private overlay?: Phaser.GameObjects.Rectangle;
  private backgroundScale = 1;
  private isReturning = false;

  constructor() {
    super('Room3Scene');
  }

  preload(): void {
    this.load.image(BACKGROUND_KEY, backgroundUrl);
  }

  create(): void {
    this.input.enabled = false;
    this.isReturning = false;
    this.cameras.main.setZoom(1).setScroll(0, 0);

    this.background = this.add.image(0, 0, BACKGROUND_KEY).setDepth(0);

    this.exit = new Doorway(this, EXIT_SIZE);
    this.exit.create();
    this.exit.setActive(true);
    this.exit.onActivate = () => this.returnToCentralHall();

    this.crystalHolder = new CrystalHolder(this);
    this.crystalHolder.create(OVERLAY_DEPTH - 10);

    this.overlay = this.add
      .rectangle(0, 0, 1, 1, 0x000000, 1)
      .setOrigin(0, 0)
      .setDepth(OVERLAY_DEPTH)
      .setAlpha(ENTRY_START_OVERLAY_ALPHA)
      .setScrollFactor(0);

    this.layout(this.scale.width, this.scale.height);
    this.scale.on(Phaser.Scale.Events.RESIZE, this.onResize, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.scale.off(Phaser.Scale.Events.RESIZE, this.onResize, this);
      this.crystalHolder?.destroy();
    });

    this.playEntryAnimation();
  }

  private onResize(gameSize: Phaser.Structs.Size): void {
    this.layout(gameSize.width, gameSize.height);
  }

  private layout(width: number, height: number): void {
    if (!this.background) {
      return;
    }

    this.backgroundScale = Math.max(width / this.background.width, height / this.background.height);
    this.background.setScale(this.backgroundScale).setPosition(width / 2, height / 2);

    const toScreenX = (bgX: number) =>
      width / 2 + (bgX - this.background!.width / 2) * this.backgroundScale;
    const toScreenY = (bgY: number) =>
      height / 2 + (bgY - this.background!.height / 2) * this.backgroundScale;

    this.exit?.layout(toScreenX(EXIT_CENTER_X), toScreenY(EXIT_CENTER_Y), this.backgroundScale);
    this.overlay?.setSize(width, height);
  }

  private playEntryAnimation(): void {
    const camera = this.cameras.main;
    camera.setZoom(ENTRY_START_ZOOM);

    this.tweens.add({
      targets: camera,
      zoom: 1,
      duration: ENTRY_SETTLE_DURATION_MS,
      ease: Phaser.Math.Easing.Sine.Out,
    });
    this.tweens.add({
      targets: this.overlay,
      alpha: 0,
      duration: ENTRY_SETTLE_DURATION_MS,
      ease: Phaser.Math.Easing.Sine.Out,
    });

    this.time.delayedCall(ENTRY_SETTLE_DURATION_MS, () => {
      this.input.enabled = true;
    });
  }

  private returnToCentralHall(): void {
    if (this.isReturning) {
      return;
    }
    this.isReturning = true;
    this.input.enabled = false;
    this.exit?.setActive(false);

    this.cameras.main.fadeOut(EXIT_FADE_MS, 0, 0, 0);
    this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.scene.start('CentralHallScene');
    });
  }
}
