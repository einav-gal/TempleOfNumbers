import Phaser from 'phaser';
import wheelUrl from '../../assets/images/central-hall/wheel.png';

const WHEEL_KEY = 'central-hall-wall-wheel';
const GLOW_KEY = 'central-hall-wall-wheel-glow';
const PASSAGE_KEY = 'central-hall-wall-wheel-passage';

const IDLE_GLOW_MIN_ALPHA = 0.18;
const IDLE_GLOW_MAX_ALPHA = 0.48;
const IDLE_GLOW_DURATION_MS = 1300;

const HOVER_SCALE = 1.035;
const HOVER_GLOW_ALPHA = 0.72;
const HOVER_TWEEN_MS = 180;

const OPEN_ROTATION_DEG = 145;
const OPEN_SHIFT_X_BG = -190;
const OPEN_DURATION_MS = 1050;

export interface WallWheelSize {
  widthBg: number;
}

/**
 * Separate wall-wheel mechanism for the Central Hall.
 *
 * The wheel is active from the beginning during the current development
 * stage. Clicking it rotates and slides it aside, revealing a dark circular
 * passage. The scene owns persistence and navigation through the callbacks.
 */
export default class WallWheel {
  private scene: Phaser.Scene;
  private size: WallWheelSize;

  private wheel?: Phaser.GameObjects.Image;
  private glow?: Phaser.GameObjects.Image;
  private passage?: Phaser.GameObjects.Image;
  private wheelZone?: Phaser.GameObjects.Zone;
  private passageZone?: Phaser.GameObjects.Zone;
  private wheelHitRect?: Phaser.Geom.Rectangle;
  private passageHitCircle?: Phaser.Geom.Circle;

  private idleGlowTween?: Phaser.Tweens.Tween;
  private hoverTween?: Phaser.Tweens.Tween;
  private openTween?: Phaser.Tweens.Tween;

  private centerX = 0;
  private centerY = 0;
  private scale = 1;
  private wheelBaseScaleX = 1;
  private wheelBaseScaleY = 1;
  private isOpening = false;
  private isOpen = false;

  onOpened?: () => void;
  onActivate?: () => void;

  constructor(scene: Phaser.Scene, size: WallWheelSize) {
    this.scene = scene;
    this.size = size;
  }

  static preload(scene: Phaser.Scene): void {
    scene.load.image(WHEEL_KEY, wheelUrl);
  }

  create(depth: number): void {
    this.generateTextures();

    this.passage = this.scene.add
      .image(0, 0, PASSAGE_KEY)
      .setDepth(depth)
      .setAlpha(0);

    this.glow = this.scene.add
      .image(0, 0, GLOW_KEY)
      .setDepth(depth + 1)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setTint(0xd9b46f)
      .setAlpha(IDLE_GLOW_MIN_ALPHA);

    this.wheel = this.scene.add
      .image(0, 0, WHEEL_KEY)
      .setDepth(depth + 2);

    this.wheelZone = this.scene.add.zone(0, 0, 1, 1).setDepth(depth + 3);
    this.wheelHitRect = new Phaser.Geom.Rectangle(0, 0, 1, 1);
    this.wheelZone.setInteractive(this.wheelHitRect, Phaser.Geom.Rectangle.Contains);
    if (this.wheelZone.input) {
      this.wheelZone.input.cursor = 'pointer';
    }

    this.passageZone = this.scene.add.zone(0, 0, 1, 1).setDepth(depth + 3);
    this.passageHitCircle = new Phaser.Geom.Circle(0, 0, 1);
    this.passageZone.setInteractive(this.passageHitCircle, Phaser.Geom.Circle.Contains);
    if (this.passageZone.input) {
      this.passageZone.input.cursor = 'pointer';
      this.passageZone.input.enabled = false;
    }

    this.wheelZone.on(Phaser.Input.Events.POINTER_OVER, () => this.setHovered(true));
    this.wheelZone.on(Phaser.Input.Events.POINTER_OUT, () => this.setHovered(false));
    this.wheelZone.on(Phaser.Input.Events.POINTER_DOWN, () => this.open());

    this.passageZone.on(Phaser.Input.Events.POINTER_OVER, () => {
      if (this.isOpen) {
        this.scene.tweens.add({
          targets: this.passage,
          alpha: 1,
          duration: HOVER_TWEEN_MS,
        });
      }
    });
    this.passageZone.on(Phaser.Input.Events.POINTER_OUT, () => {
      if (this.isOpen) {
        this.scene.tweens.add({
          targets: this.passage,
          alpha: 0.9,
          duration: HOVER_TWEEN_MS,
        });
      }
    });
    this.passageZone.on(Phaser.Input.Events.POINTER_DOWN, () => {
      if (!this.isOpen) {
        return;
      }
      this.setPassageInteractive(false);
      this.onActivate?.();
    });

    this.startIdleGlow();
  }

  layout(centerX: number, centerY: number, backgroundScale: number): void {
    this.centerX = centerX;
    this.centerY = centerY;
    this.scale = backgroundScale;

    const displayWidth = this.size.widthBg * backgroundScale;
    const texture = this.wheel?.texture.getSourceImage() as HTMLImageElement | HTMLCanvasElement | undefined;
    const textureWidth = texture?.width ?? 158;
    const textureHeight = texture?.height ?? 141;
    const displayHeight = displayWidth * (textureHeight / textureWidth);

    const shiftX = this.isOpen ? OPEN_SHIFT_X_BG * backgroundScale : 0;

    this.wheel
      ?.setPosition(centerX + shiftX, centerY)
      .setDisplaySize(displayWidth, displayHeight)
      .setAngle(this.isOpen ? OPEN_ROTATION_DEG : 0);

    if (this.wheel) {
      this.wheelBaseScaleX = this.wheel.scaleX;
      this.wheelBaseScaleY = this.wheel.scaleY;
    }

    this.glow
      ?.setPosition(centerX, centerY)
      .setDisplaySize(displayWidth * 1.35, displayWidth * 1.35);

    const passageSize = displayWidth * 0.74;
    this.passage
      ?.setPosition(centerX, centerY)
      .setDisplaySize(passageSize, passageSize);

    this.wheelZone?.setPosition(centerX, centerY).setSize(displayWidth, displayHeight);
    if (this.wheelHitRect) {
      this.wheelHitRect.width = displayWidth;
      this.wheelHitRect.height = displayHeight;
    }

    this.passageZone?.setPosition(centerX, centerY).setSize(passageSize, passageSize);
    if (this.passageHitCircle) {
      this.passageHitCircle.x = passageSize / 2;
      this.passageHitCircle.y = passageSize / 2;
      this.passageHitCircle.radius = passageSize / 2;
    }
  }

  restoreOpen(): void {
    this.isOpening = false;
    this.isOpen = true;
    this.idleGlowTween?.stop();
    this.glow?.setAlpha(0.22);
    this.passage?.setAlpha(0.9);
    this.setWheelInteractive(false);
    this.setPassageInteractive(true);
    this.layout(this.centerX, this.centerY, this.scale);
  }

  getOpeningBounds(): { centerX: number; centerY: number; width: number; height: number } | undefined {
    if (!this.isOpen || !this.passage) {
      return undefined;
    }
    return {
      centerX: this.passage.x,
      centerY: this.passage.y,
      width: this.passage.displayWidth,
      height: this.passage.displayHeight,
    };
  }

  destroy(): void {
    this.idleGlowTween?.stop();
    this.hoverTween?.stop();
    this.openTween?.stop();
    this.wheel?.destroy();
    this.glow?.destroy();
    this.passage?.destroy();
    this.wheelZone?.destroy();
    this.passageZone?.destroy();
  }

  private open(): void {
    if (this.isOpening || this.isOpen || !this.wheel) {
      return;
    }
    this.isOpening = true;
    this.setWheelInteractive(false);
    this.idleGlowTween?.stop();

    const targetX = this.centerX + OPEN_SHIFT_X_BG * this.scale;
    this.openTween = this.scene.tweens.add({
      targets: this.wheel,
      x: targetX,
      angle: OPEN_ROTATION_DEG,
      duration: OPEN_DURATION_MS,
      ease: Phaser.Math.Easing.Cubic.InOut,
    });

    this.scene.tweens.add({
      targets: this.glow,
      alpha: 0.22,
      duration: OPEN_DURATION_MS,
      ease: Phaser.Math.Easing.Sine.InOut,
    });

    this.scene.tweens.add({
      targets: this.passage,
      alpha: 0.9,
      delay: 280,
      duration: OPEN_DURATION_MS - 280,
      ease: Phaser.Math.Easing.Sine.InOut,
      onComplete: () => {
        this.isOpening = false;
        this.isOpen = true;
        this.setPassageInteractive(true);
        this.onOpened?.();
      },
    });
  }

  private setHovered(hovered: boolean): void {
    if (this.isOpening || this.isOpen) {
      return;
    }
    this.hoverTween?.stop();
    this.hoverTween = this.scene.tweens.add({
      targets: this.wheel,
      scaleX: this.wheelBaseScaleX * (hovered ? HOVER_SCALE : 1),
      scaleY: this.wheelBaseScaleY * (hovered ? HOVER_SCALE : 1),
      duration: HOVER_TWEEN_MS,
      ease: Phaser.Math.Easing.Sine.InOut,
    });
    if (this.glow) {
      this.scene.tweens.add({
        targets: this.glow,
        alpha: hovered ? HOVER_GLOW_ALPHA : IDLE_GLOW_MIN_ALPHA,
        duration: HOVER_TWEEN_MS,
      });
    }
  }

  private startIdleGlow(): void {
    if (!this.glow) {
      return;
    }
    this.idleGlowTween?.stop();
    this.glow.setAlpha(IDLE_GLOW_MIN_ALPHA);
    this.idleGlowTween = this.scene.tweens.add({
      targets: this.glow,
      alpha: IDLE_GLOW_MAX_ALPHA,
      duration: IDLE_GLOW_DURATION_MS,
      yoyo: true,
      repeat: -1,
      ease: Phaser.Math.Easing.Sine.InOut,
    });
  }

  private setWheelInteractive(active: boolean): void {
    if (this.wheelZone?.input) {
      this.wheelZone.input.enabled = active;
    }
  }

  private setPassageInteractive(active: boolean): void {
    if (this.passageZone?.input) {
      this.passageZone.input.enabled = active;
    }
  }

  private generateTextures(): void {
    if (!this.scene.textures.exists(GLOW_KEY)) {
      const size = 192;
      const canvas = this.scene.textures.createCanvas(GLOW_KEY, size, size);
      if (canvas) {
        const ctx = canvas.getContext();
        const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
        gradient.addColorStop(0, 'rgba(255,235,180,0.95)');
        gradient.addColorStop(0.45, 'rgba(214,167,87,0.38)');
        gradient.addColorStop(1, 'rgba(120,75,25,0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, size, size);
        canvas.refresh();
      }
    }

    if (!this.scene.textures.exists(PASSAGE_KEY)) {
      const size = 192;
      const canvas = this.scene.textures.createCanvas(PASSAGE_KEY, size, size);
      if (canvas) {
        const ctx = canvas.getContext();
        const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
        gradient.addColorStop(0, 'rgba(2,2,3,1)');
        gradient.addColorStop(0.7, 'rgba(7,7,8,1)');
        gradient.addColorStop(0.88, 'rgba(35,31,25,1)');
        gradient.addColorStop(1, 'rgba(150,112,60,0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, size, size);
        canvas.refresh();
      }
    }
  }
}
