import Phaser from 'phaser';
import mapImageUrl from '../../assets/images/Room3/map.png';
import FeedbackPopup from './FeedbackPopup';
import { isRoom3PuzzleSolved, setRoom3PuzzleSolved, setCrystalCollected } from './GameState';
import type CrystalHolder from './CrystalHolder';

/**
 * Room 3 — fraction map puzzle. The entire question (title, 8-cell map,
 * and the three answer cards) is one baked image; this class only adds
 * the interactive layer on top of it: three invisible hit zones over the
 * baked cards, a correct/incorrect feedback popup (reusing the shared
 * FeedbackPopup used by the other two rooms' puzzles), a green glow on
 * solve, and the registry/crystal-collection side effects.
 *
 * Deliberately CONTAIN-fit (never cropped), unlike the cover-scaled hall
 * background — this image is a functional UI surface (it has clickable
 * answers baked into it), so no edge of it may ever be cut off or it
 * would hide an option or the room's own stairwell opening. Always
 * centered in whatever safe area the owning scene provides.
 */

const TEXTURE_KEY = 'room3-map-puzzle';

// Natural size of map.png (verified: 1536x1024 — the project's standard
// background resolution, so no separate scale-reference is needed).
const NATURAL_WIDTH = 1536;
const NATURAL_HEIGHT = 1024;

// Never upscale the art past this multiple of its native size, even if
// the available safe area is huge (avoids visibly soft/blurry text on
// very large viewports) — the image still always fits fully within the
// safe area at or below this cap.
const MAX_DISPLAY_SCALE = 1.15;

// Source-pixel crop rects for the three answer cards, measured directly
// from map.png. Used both as the interactive hit areas and as the crop
// for a duplicate "overlay" image of the exact same pixels, so a wrong
// answer's shake genuinely moves that card's art without touching
// anything else baked into the image.
interface CardRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

const CARD_CORRECT: CardRect = { x: 312, y: 688, w: 213, h: 240 }; // "6/8"
const CARD_WRONG_MID: CardRect = { x: 576, y: 689, w: 208, h: 237 }; // "3/8"
const CARD_WRONG_RIGHT: CardRect = { x: 836, y: 689, w: 208, h: 237 }; // "2/8"

const FEEDBACK_CORRECT_TITLE = 'נכון!';
const FEEDBACK_CORRECT_BODY = '6 מתוך 8 חלקים מוארים';
const FEEDBACK_WRONG_TITLE = 'נסו שוב';
const FEEDBACK_WRONG_BODY = '';

const CORRECT_FEEDBACK_MS = 1800;
const INCORRECT_FEEDBACK_MS = 1200;

const SHAKE_OFFSET_PX = 6;
const SHAKE_TWEEN_MS = 70;
const SHAKE_REPEATS = 2;

const GLOW_COLOR = 0x4ade80; // matches the CrystalHolder's green-crystal tint
const GLOW_TWEEN_MS = 500;
const GLOW_OUTER_STRENGTH = 3;

export interface MapFractionPuzzleConfig {
  scene: Phaser.Scene;
  /** Depth for the whole puzzle (image + overlays + glow). */
  depth: number;
  /** Optional: if provided, revealCollected('green') is called on solve so the holder pops immediately. */
  crystalHolder?: CrystalHolder;
  /** Fires exactly once, only the moment the puzzle is actually solved (never on a restore). */
  onSolved?: () => void;
}

interface CardOverlay {
  image: Phaser.GameObjects.Image;
  rect: CardRect;
}

export default class MapFractionPuzzle {
  private scene: Phaser.Scene;
  private config: MapFractionPuzzleConfig;
  private container?: Phaser.GameObjects.Container;
  private mainImage?: Phaser.GameObjects.Image;
  private correctOverlay?: CardOverlay;
  private wrongOverlays: CardOverlay[] = [];
  private feedbackPopup: FeedbackPopup;
  private solved = false;
  private locked = false;
  private currentScale = 1;

  constructor(config: MapFractionPuzzleConfig) {
    this.scene = config.scene;
    this.config = config;
    this.feedbackPopup = new FeedbackPopup(config.scene);
  }

  static preload(scene: Phaser.Scene): void {
    scene.load.image(TEXTURE_KEY, mapImageUrl);
  }

  /**
   * Builds the puzzle centered at (centerX, centerY) inside a
   * (maxWidth x maxHeight) safe area — the owning scene is responsible
   * for choosing that safe area so it never overlaps the room's own
   * stairwell exit hotspot. Call layout() again on resize.
   */
  create(centerX: number, centerY: number, maxWidth: number, maxHeight: number): void {
    this.solved = isRoom3PuzzleSolved(this.scene.registry);

    const container = this.scene.add.container(centerX, centerY).setDepth(this.config.depth);
    this.container = container;

    const mainImage = this.scene.add.image(0, 0, TEXTURE_KEY).setOrigin(0.5, 0.5);
    container.add(mainImage);
    this.mainImage = mainImage;

    this.correctOverlay = this.createCardOverlay(container, CARD_CORRECT, true);
    this.wrongOverlays = [
      this.createCardOverlay(container, CARD_WRONG_MID, false),
      this.createCardOverlay(container, CARD_WRONG_RIGHT, false),
    ];

    if (this.solved) {
      // Restore path: glow already fully on, no interactivity, no replay.
      this.applyGlow(false);
    } else {
      this.wireInteraction();
    }

    this.layout(centerX, centerY, maxWidth, maxHeight);
  }

  /** Re-centers and re-scales everything — call on resize with the scene's current safe area. */
  layout(centerX: number, centerY: number, maxWidth: number, maxHeight: number): void {
    if (!this.container || !this.mainImage) {
      return;
    }
    const fitScale = Math.min(maxWidth / NATURAL_WIDTH, maxHeight / NATURAL_HEIGHT);
    const scale = Math.min(fitScale, MAX_DISPLAY_SCALE);
    this.currentScale = scale;

    this.container.setPosition(centerX, centerY);
    this.mainImage.setDisplaySize(NATURAL_WIDTH * scale, NATURAL_HEIGHT * scale);

    const allOverlays = [this.correctOverlay, ...this.wrongOverlays].filter(
      (o): o is CardOverlay => o !== undefined,
    );
    for (const overlay of allOverlays) {
      this.positionOverlay(overlay, scale);
    }
  }

  destroy(): void {
    this.feedbackPopup.destroy();
    this.container?.destroy();
  }

  // ---- internals ----------------------------------------------------------

  private createCardOverlay(container: Phaser.GameObjects.Container, rect: CardRect, isCorrect: boolean): CardOverlay {
    const image = this.scene.add.image(0, 0, TEXTURE_KEY).setOrigin(0.5, 0.5);
    image.setCrop(rect.x, rect.y, rect.w, rect.h);
    container.add(image);
    return { image, rect };
  }

  private positionOverlay(overlay: CardOverlay, scale: number): void {
    const { rect, image } = overlay;
    const cardCenterSrcX = rect.x + rect.w / 2;
    const cardCenterSrcY = rect.y + rect.h / 2;
    const localX = (cardCenterSrcX - NATURAL_WIDTH / 2) * scale;
    const localY = (cardCenterSrcY - NATURAL_HEIGHT / 2) * scale;
    image.setPosition(localX, localY);
    image.setDisplaySize(rect.w * scale, rect.h * scale);
  }

  private wireInteraction(): void {
    if (this.correctOverlay) {
      this.correctOverlay.image.setInteractive({ useHandCursor: true });
      this.correctOverlay.image.on(Phaser.Input.Events.POINTER_DOWN, () => this.handleCorrectAnswer());
    }
    for (const overlay of this.wrongOverlays) {
      overlay.image.setInteractive({ useHandCursor: true });
      overlay.image.on(Phaser.Input.Events.POINTER_DOWN, () => this.handleWrongAnswer(overlay));
    }
  }

  private disableInteraction(): void {
    this.correctOverlay?.image.disableInteractive();
    for (const overlay of this.wrongOverlays) {
      overlay.image.disableInteractive();
    }
  }

  private handleWrongAnswer(overlay: CardOverlay): void {
    if (this.solved || this.locked) {
      return;
    }
    this.locked = true;
    this.shake(overlay.image);
    this.feedbackPopup.show(
      { kind: 'incorrect', title: FEEDBACK_WRONG_TITLE, body: FEEDBACK_WRONG_BODY },
      INCORRECT_FEEDBACK_MS,
      () => {
        this.locked = false;
      },
    );
  }

  private handleCorrectAnswer(): void {
    if (this.solved || this.locked) {
      return;
    }
    this.locked = true;
    this.solved = true;

    this.applyGlow(true);
    this.feedbackPopup.show(
      { kind: 'correct', title: FEEDBACK_CORRECT_TITLE, body: FEEDBACK_CORRECT_BODY },
      CORRECT_FEEDBACK_MS,
      () => {
        this.locked = false;
      },
    );

    setRoom3PuzzleSolved(this.scene.registry);
    setCrystalCollected(this.scene.registry, 'green');
    this.config.crystalHolder?.revealCollected('green');
    this.disableInteraction();
    this.config.onSolved?.();
  }

  private shake(target: Phaser.GameObjects.Image): void {
    const originalX = target.x;
    this.scene.tweens.add({
      targets: target,
      x: { from: originalX - SHAKE_OFFSET_PX, to: originalX + SHAKE_OFFSET_PX },
      duration: SHAKE_TWEEN_MS,
      yoyo: true,
      repeat: SHAKE_REPEATS,
      ease: Phaser.Math.Easing.Sine.InOut,
      onComplete: () => target.setX(originalX),
    });
  }

  private applyGlow(animateIn: boolean): void {
    if (!this.mainImage) {
      return;
    }
    // Reuses this project's established postFX glow technique (see the
    // Central Hall crystal's pulsing glow) rather than a new hand-rolled
    // texture — same family of effect, just a steady green "solved" glow
    // instead of a pulse.
    const fx = this.mainImage.postFX?.addGlow(GLOW_COLOR, 0, 0, false, 0.1, 24);
    if (!fx) {
      return;
    }
    if (!animateIn) {
      fx.outerStrength = GLOW_OUTER_STRENGTH;
      return;
    }
    this.scene.tweens.add({
      targets: fx,
      outerStrength: GLOW_OUTER_STRENGTH,
      duration: GLOW_TWEEN_MS,
      ease: Phaser.Math.Easing.Sine.Out,
    });
  }
}
